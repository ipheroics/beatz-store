# MrBeatz Admin Dashboard

Deployment-ready admin panel for beat store.